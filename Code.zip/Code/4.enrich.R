source("src/0.config.R")

od <- "结果/4.不同分子亚型功能富集分析"
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
using(clusterProfiler,data.table,enrichplot)
conflicts_prefer(base::as.data.frame)
gene=fread("结果/3.构建SUMOylation相关的分子亚型/cluster1_gene_name.csv")
length(gene$Symbol)
enrich(genetype = "Cluster1", genelist = gene$Symbol, od = paste0(od,"/Cluster1"), color_fun = rainbow(5))

gene=fread("结果/3.构建SUMOylation相关的分子亚型/cluster2_gene_name.csv")
length(gene$Symbol)
enrich(genetype = "Cluster2", genelist = gene$Symbol, od = paste0(od,"/Cluster2"), color_fun = rainbow(5))

gene=fread("结果/3.构建SUMOylation相关的分子亚型/cluster3_gene_name.csv")
length(gene$Symbol)
enrich(genetype = "Cluster3", genelist = gene$Symbol, od = paste0(od,"/Cluster3"), color_fun = rainbow(5))
