source("src/0.config.R")

od <- "结果/3.构建SUMOylation相关的分子亚型"
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
using(clusterProfiler,data.table,enrichplot,NMF)
load("data/train_data.RData")
load("data/xgene.RData")
# "brunet"    "KL"        "lee"       "Frobenius" "offset"    "nsNMF"    
# "ls-nmf"    "pe-nmf"    "siNMF"     "snmf/r"    "snmf/l"   

range(train_data$tumor_exprs)
source("src/functions/run_nmf.R")

res <- run_nmf(
    exp=train_data$tumor_exprs,
    genelist=xgene,
    od=od,
    # od="temp",
    n_cluster=3,
    method="KL",
    cluster_range = 2:10,
    # cluster_range = NULL,
    clin=train_data$data_clinical,
    timecol = "OS.Time",
    n_run=10,
    seed=764323,
    # seed=8654752,# 
    statuscol = "OS.Status", 
    cluster_character = "Cluster",
    xlab = "days"
    ) 


gene <- fread("结果/3.构建SUMOylation相关的分子亚型/cluster1_gene.csv",header = F)
length(gene$V1)
fwrite(data.table(Symbol=xgene[gene$V1]),"结果/3.构建SUMOylation相关的分子亚型/cluster1_gene_name.csv")

gene <- fread("结果/3.构建SUMOylation相关的分子亚型/cluster2_gene.csv",header = F)
length(gene$V1)
fwrite(data.table(Symbol=xgene[gene$V1]),"结果/3.构建SUMOylation相关的分子亚型/cluster2_gene_name.csv")

gene <- fread("结果/3.构建SUMOylation相关的分子亚型/cluster3_gene.csv",header = F)
length(gene$V1)
fwrite(data.table(Symbol=xgene[gene$V1]),"结果/3.构建SUMOylation相关的分子亚型/cluster3_gene_name.csv")

