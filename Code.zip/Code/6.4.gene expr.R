source("src/0.config.R")
conflict_prefer("between", "dplyr",quiet = TRUE)
source("src/functions/v_characteristics_plot_by_group.R")
# 设置结果路径
od <- "结果/6.不同分子亚型的免疫治疗和化疗敏感性分析"
suppressWarnings(dir.create(od,recursive=TRUE))

# 导入数据
load("data/train_data.RData")
load("data/xgene.RData")
NMF_Cluster <- fread("结果/3.构建SUMOylation相关的分子亚型/NMF_Cluster.csv",data.table = F) %>% 
    column_to_rownames("Sample")
table(NMF_Cluster$Cluster)
checkpoints_data <- readxl::read_xlsx(paste0(Data_Center,"/Gene_Sets/immune_features/checkpiont.xlsx")) %>%
    mutate(Type = case_when(
        Role.with.Immunity %in% c("Activate", "Active") ~ "Activate",
        Role.with.Immunity %in% c("Inhibit") ~ "Inhibit",
        Role.with.Immunity %in% c("TwoSide") ~ "TwoSide"
    )) %>%
    arrange(Type, Symbol)

# 全部的结果

v_characteristics_plot_by_group(
    characteristics_score = train_data$tumor_exprs[rownames(train_data$tumor_exprs) %in% checkpoints_data$Symbol, ] %>%
        t() %>%
        as.data.frame() %>%
        rownames_to_column("sample"),
    Group = NMF_Cluster, od = str_c(od, "/免疫检查点/all"), type = "all"
)

# 挑选显著的进行box展示
sign_checkpoints <- read.delim(file = str_glue("{od}/all/SupplementaryTable_all_sign_stat.txt")) %>%
    rownames_to_column("checkpoints") %>%
    filter(pvalue < 0.05) %>%
    pull(checkpoints)
v_characteristics_plot_by_group(
    characteristics_score = train_data$tumor_exprs[rownames(train_data$tumor_exprs) %in% sign_checkpoints, ] %>%
        t() %>%
        as.data.frame() %>%
        rownames_to_column("sample"),
    Group = NMF_Cluster, od = str_c(od, "/免疫检查点/significant_checkpoint"), type = "all"
)

gene <- readxl::read_xlsx(paste0(Data_Center,"/Gene_Sets/immune_features/IFN_gamma.xlsx")) %>% pull(1)
v_characteristics_plot_by_group(
    characteristics_score = train_data$tumor_exprs[rownames(train_data$tumor_exprs) %in% gene, ] %>%
        t() %>%
        as.data.frame() %>%
        rownames_to_column("sample"),
    Group = NMF_Cluster, od = str_c(od, "/IFNG"), type = "IFNG"
)

gene <- readxl::read_xlsx(paste0(Data_Center,"/Gene_Sets/immune_features/HLA.xlsx")) %>% pull(1)
v_characteristics_plot_by_group(
    characteristics_score = train_data$tumor_exprs[rownames(train_data$tumor_exprs) %in% gene, ] %>%
        t() %>%
        as.data.frame() %>%
        rownames_to_column("sample"),
    Group = NMF_Cluster, od = str_c(od, "/HLA"), type = "HLA"
)

