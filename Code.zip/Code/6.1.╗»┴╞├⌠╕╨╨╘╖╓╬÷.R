source("src/0.config.R")

od <- "结果/6.不同分子亚型的免疫治疗和化疗敏感性分析/化疗敏感性分析"
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
using(clusterProfiler,data.table,enrichplot)

# 导入数据
load("data/train_data.RData")
NMF_Cluster <- fread("结果/3.构建SUMOylation相关的分子亚型/NMF_Cluster.csv",data.table = F) %>% 
    column_to_rownames("Sample")

data_ic50 <- oncoPredict_calcPhenotype(
    valid_exp = train_data$tumor_exprs, 
    database = "GDSC2", drug_list = NULL, train_exp = NULL, 
    train_ptype = NULL, 
    od = '/Users/victor'
    )

IC50 <- fread("结果/6.不同分子亚型的免疫治疗和化疗敏感性分析/化疗敏感性分析/DrugPredictions.csv") %>% 
    as.data.frame() %>%
    mutate_if(is.numeric, log2) %>%
    rename(sample = 1) %>%
    mutate(sample = substr(sample, 1, 16)) %>%
    column_to_rownames("sample")
names(IC50)
library(psych)
samples <- intersect(rownames(IC50), rownames(NMF_Cluster))
IC50 <- as_tibble(IC50[samples, ], rownames = "sample")

source("src/functions/v_characteristics_plot_by_group.R")

conflicts_prefer(dplyr::between)
v_characteristics_plot_by_group(
    characteristics_score = IC50,
    Group = NMF_Cluster, od = od, type = "GDSC2",feature2show=6,
)

