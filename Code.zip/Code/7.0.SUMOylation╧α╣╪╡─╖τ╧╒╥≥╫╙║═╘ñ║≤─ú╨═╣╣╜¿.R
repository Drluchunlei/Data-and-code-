source("src/0.config.R")
od <- "结果/7.SUMOylation相关的风险因子和预后模型构建/DEG/"
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
conflicts_prefer(base::intersect)
using(data.table,NMF)
load("data/train_data.RData")
load("data/xgene.RData")
xgene_cluster <- fread("结果/3.构建SUMOylation相关的分子亚型/NMF_Cluster.csv") %>% rename(sample=Sample)

# one vs rest做差异，取上调的并集
unique_cluster <- unique(xgene_cluster$Cluster) %>% sort()
combine_deg_res <- map_dfr(unique_cluster, function(x) {
    sample_pdata <- xgene_cluster %>% dplyr::mutate(Cluster = ifelse(Cluster == x, x, "Rest"))
    deg_res <- limma_deg(
        od = od, DEG_exp = train_data$tumor_exprs, DEG_pdata = as.data.frame(sample_pdata),
        controlLabel = "Rest", caseLabel = x,
        DEG_FC = parameter_list$log2fc, DEG_P = parameter_list$deg_p, pvalue = NULL, saveplot = T, color_fun = color_fun1
    )
    return(deg_res$nrDEG %>% rownames_to_column("gene") %>% dplyr::mutate(Cluster = x))
})

combine_deg_res %>% dplyr::filter(Diff != "not-significant") %>% dplyr::pull(Cluster) %>% table()
Cluster1 Cluster2 Cluster3 
    5511     2711     1526 
combine_deg_res %>% head
deg_gene <- combine_deg_res %>%
    dplyr::filter(Diff != "not-significant") %>%
    pull(gene) %>%
    unique()
using(ggvenn)
x <- list(DEGs=deg_gene,SUMOylation=xgene)
ggvenn(x,show_percentage = F,text_size = 8,
    fill_color = c("#8796d6", "#e68d8d"),fill_alpha = 0.7,
    stroke_size = 0.5,stroke_color=c("#8796d6"))
ggsave(str_glue("{od}/venn.pdf"),width = 6,height = 6)

write.table(deg_gene, file = str_glue("{od}/SupplementaryTable_combine_DEGs.txt"), sep = "\t", quote = F, row.names = F, col.names = F)
save(deg_gene, file = str_glue("{od}/deg_gene.RData"))
com_gene <- reduce(x,intersect)
save(com_gene,file=str_glue("{od}/com_gene.RData"))
# deg_res <- limma_deg(
#     od = od, DEG_exp = train_data$tumor_exprs, DEG_pdata = xgene_cluster,
#     controlLabel = "Cluster1", caseLabel = "Cluster2",
#     DEG_FC = parameter_list$log2fc, DEG_P = parameter_list$deg_p, pvalue = NULL, saveplot = TRUE, color_fun = color_fun1
# )
# fun_res <- enrich(genetype = "DEGs", genelist = deg_gene, od = od)
