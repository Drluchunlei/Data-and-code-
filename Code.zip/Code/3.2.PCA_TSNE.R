source("src/0.config.R")
od <- "结果/3.构建SUMOylation相关的分子亚型"
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
using(data.table,NMF)
load("data/train_data.RData")
load("data/xgene.RData")
xgene_cluster <- fread("结果/3.构建SUMOylation相关的分子亚型/NMF_Cluster.csv")
fwrite(as.data.table(train_data$tumor_exprs,keep.rownames="Symbol"),str_c(od,"/tumor.csv.gz"))

dat = train_data$tumor_exprs[xgene,xgene_cluster$Sample] %>% na.omit() %>% t()
using(FactoMineR,factoextra)
pca = PCA(dat, scale.unit = F, ncp = 2, graph = F)
p = fviz_pca_ind(X = pca, ## pca对象
  axes = 1:2, ## 展示的两个主成分
  geom = 'point', ## 展示individual的形式
  habillage = factor(xgene_cluster$Cluster,sort(unique(xgene_cluster$Cluster))), ## individual用来分组的变量
  legend.title = 'Groups', ## 分组变量的title
  palette = 'lancet', ## 颜色面板
  addEllipses = T,  ## 是否绘制椭圆
  ellipse.level = 0.5, ## 椭圆的大小
  title = 'PCA Plot', ## 标题
  mean.point = F ## 不删除每个组的重心
  )+
  theme(plot.title = element_text(hjust = 0.5,size=20))
p
ggsave(plot = p,str_c(od,"/xgene_PCA2d_cluster.pdf"),width=6,height=5)

# library(pca3d)
# ------------------制作数据------------------
dt <- iris[, -5]
rownames(dt) <- paste0("sample", 1:nrow(dt))
dt

# ------------------计算PCA------------------

# pkg_install("url::https://cran.r-project.org/src/contrib/Archive/pca3d/pca3d_0.10.2.tar.gz")
# local_install("pca3d")
# using(pca3d)
# pca <- princomp(dat) # 变量在列
# gr <- factor(xgene_cluster$Cluster,unique(xgene_cluster$Cluster))# 分组信息
# pcs <- pca$sdev^2 / sum(pca$sdev^2) * 100 #计算主成分贡献

# pca3d(pca,
#     palette=c("#1B9E77", "#D95F02", "#7570B3"),
#     group = gr, new = T,
#     axe.titles = sprintf(c("PC1: %.2f %%", "PC2: %.2f %%", "PC3: %.2f %%"), pcs[1:3]),
#     show.centroids = T,
#     legend = "right",
#     show.plane = FALSE,
#     show.shapes = TRUE
# )
# snapshotPCA3d("pca3d.png") # macbook需要安装XQuartz
gr <- factor(xgene_cluster$Cluster,unique(xgene_cluster$Cluster))
# pkg_install("Rtsne")
using(Rtsne)
set.seed(1314)
tsne_out <- Rtsne::Rtsne(dat)
pdf(str_c(od,"/xgene_tsne_cluster.pdf"))
plot(tsne_out$Y,col=gr, asp=1,pch=20,
     xlab = "tSNE_1",ylab = "tSNE_2",main = "tSNE plot")
legend("topright",title = "Cluster",inset = 0.01,
       legend = sort(unique(xgene_cluster$Cluster)),pch=16,
       col = gr)
dev.off()
