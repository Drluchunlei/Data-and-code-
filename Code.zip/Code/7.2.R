source("src/0.config.R")
od <- "结果/7.SUMOylation相关的风险因子和预后模型构建/model/"
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
conflicts_prefer(base::intersect)
load("data/train_data.RData")
load("data/xgene.RData")
load("结果/7.SUMOylation相关的风险因子和预后模型构建/单因素cox/cox_res.RData")

using(survival,survminer)

source("src/functions/lasso_model.R")
signature_coef <- lasso_model(
    timecol = paste0(parameter_list$train_survival_outcome[1], ".Time"),
    statuscol = paste0(parameter_list$train_survival_outcome[1], ".Status"),
    signaturelist = cox_res$cox_signature,
    od = od,
    rng = 1314,
    exp = train_data$tumor_exprs,
    clin = train_data$data_clinical,
    signaturetype = "cox_gene"
)

conflict_prefer("ggarrange", "ggpubr")
train_model_res <- modelscore_km_roc(
    timecol = paste0(parameter_list$train_survival_outcome[1], ".Time"),
    statuscol = paste0(parameter_list$train_survival_outcome[1], ".Status"),
    signature_coef = signature_coef,
    od = str_glue("{od}/train/"),
    roc_time = parameter_list$roc_time,
    no_roc_pheatmap = F,
    exp = train_data$tumor_exprs,
    clin = train_data$data_clinical,
    dataset = parameter_list$train_cohort,
    xlab = str_c(parameter_list$train_survival_outcome, " days")
)

save(train_model_res, file = str_glue("{od}/train_model_res.RData"))
save(signature_coef, file = str_glue("{od}/signature_coef.RData"))
# 评分系统的预后独立性
res <- uni_multi_cox(
    timecol = paste0(parameter_list$train_survival_outcome[1], ".Time"),
    statuscol = paste0(parameter_list$train_survival_outcome[1], ".Status"),
    od = str_glue("{od}/train/"),
    infor = train_model_res$Group %>% rownames_to_column("sample") %>% merge(., train_data$data_clinical) %>% rename(Score = Group),
    factors = c(parameter_list$clinical_feature_list, "Score"),
    dataset = parameter_list$train_cohort, coxp = 1, w = 10
)

