source("src/0.config.R")
od <- "结果/7.SUMOylation相关的风险因子和预后模型构建/单因素cox"
conflicts_prefer(clusterProfiler::rename)
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
conflicts_prefer(base::intersect)
load("data/train_data.RData")
load("data/xgene.RData")
load("结果/7.SUMOylation相关的风险因子和预后模型构建/DEG/com_gene.RData")
xgene_cluster <- fread("结果/3.构建SUMOylation相关的分子亚型/NMF_Cluster.csv") %>% rename(sample=Sample)

# 导入数据

# 单因素cox
cox_res <- signature_cox(
    timecol = paste0(parameter_list$train_survival_outcome[1],".Time"),
    statuscol = paste0(parameter_list$train_survival_outcome[1],".Status"),
    signaturelist = com_gene, exp = train_data$tumor_exprs, clin = train_data$data_clinical, coxp = parameter_list$coxp, 
    bygroup = parameter_list$gene_cox_bygroup, xlab = str_c(parameter_list$train_survival_outcome, " days"), savekmplot = FALSE
)
# num of signature used for cox is 77
# cox signature num is 11
# top20预后基因森林图
# 森林图
forest_plot(
    od = od, input = cox_res$sigcoxResult %>% rownames_to_column("gene") %>% arrange(pvalue), plotN = 20, 
    dataset = parameter_list$train_cohort, h = 8, w = 8,
    signaturecol = "gene", pvaluecol = "pvalue", HRcol = "HR", lower95col = "Low 95%CI",
    upper95col = "High 95%CI"
)

# top6预后基因生存曲线
# length(cox_res$cox_signature)
# row_n <- 2
# col_n <- 3
# p <- survminer::arrange_ggsurvplots(cox_res$kmplot[1:(row_n * col_n)], newPage = F, nrow = row_n, ncol = col_n)
# plotout(p = p, od = od, name = "deg_gene_cox_kmplot", w = col_n * 5, h = row_n * 5)
# dev.off()

write.table(cox_res$sigcoxResult, file = str_glue("{od}/SupplementaryTable_cox_signature_coxResult.txt"), quote = FALSE, sep = "\t", row.names = TRUE, col.names = TRUE)
save(cox_res, file = str_glue("{od}/cox_res.RData"))
