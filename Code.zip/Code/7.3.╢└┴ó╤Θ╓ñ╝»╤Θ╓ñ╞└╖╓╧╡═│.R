source("src/0.config.R")
od <- "结果/7.SUMOylation相关的风险因子和预后模型构建/validate/"
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
conflicts_prefer(base::intersect)
load("data/train_data.RData")
load("data/xgene.RData")
load("结果/7.SUMOylation相关的风险因子和预后模型构建/单因素cox/cox_res.RData")
load("结果/7.SUMOylation相关的风险因子和预后模型构建/model/signature_coef.RData")
# 阳性的验证集

source("src/functions/v_datacenter_validation.R")
DATA_DIR = '/Volumes/T7/DataHub'

valid_model_res <- v_datacenter_validation(
    signature_coef = signature_coef,
    od = od,
    edition="v1",
    cox_tibble = cox_res$coxResult,
    cancer = "COAD",
    outcome_list = parameter_list$valid_survival_outcome_list,
    method = parameter_list$model,
    time = c(1,3,5),
    best_cut=F,
    prognostic_independence = T,
    cohort_list=c("GSE17538_GPL570"),
    factors = c("Age", "Sex","Stage")
)

valid_model_res <- v_datacenter_validation(
    signature_coef = signature_coef,
    od = od,
    edition="v3",
    cox_tibble = cox_res$coxResult,
    cancer = "COADREAD",
    outcome_list = parameter_list$valid_survival_outcome_list,
    method = parameter_list$model,
    time = c(1,3,5),
    best_cut=F,
    prognostic_independence = T,
    cohort_list=c("XZ0022_GSE17536_GPL570_COADREAD/output"),
    factors = c("Age", "Sex","Grade","Stage")
)
# save(valid_model_res, file = str_glue("{od}/valid_model_res.RData"))

# load("/Volumes/T7/DataHub/GEO/v3/XZ0022_GSE17536_GPL570_COADREAD/output/clinical.RData")
# colnames(clinical)
# grep("HIST1H4D",rownames(expression),ignore.case=T,value=T)
# rownames(expression) <- str_replace(rownames(expression),"HIST1H4D","H4C4")
# save(expression,file="/Volumes/T7/DataHub/GEO/v3/XZ0022_GSE17536_GPL570_COADREAD/output/expression.RData")

# load("/Volumes/T7/DataHub/GEO/v1/GSE17538_GPL570/expression.RData")
# grep("MAL",rownames(expression),ignore.case=T,value=T)
# rownames(expression) <- str_replace(rownames(expression),"MAL","MRTFA")
# rownames(expression) <- str_replace(rownames(expression),"SUMO3","SUMO2")
# expression["H4C4",]
# save(expression,file="/Volumes/T7/DataHub/GEO/v1/GSE17538_GPL570/expression.RData")





