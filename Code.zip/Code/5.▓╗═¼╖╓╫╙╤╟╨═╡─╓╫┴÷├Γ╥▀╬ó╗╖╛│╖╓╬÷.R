source("src/0.config.R")

od <- "结果/5.不同分子亚型的肿瘤免疫微环境分析/"
suppressWarnings(dir.create(od,recursive=TRUE))
conflicts_prefer(base::setdiff, .quiet = TRUE)
using(clusterProfiler,data.table,enrichplot)

# 导入数据
load("data/train_data.RData")
NMF_Cluster <- fread("结果/3.构建SUMOylation相关的分子亚型/NMF_Cluster.csv",data.table = F) %>% 
    column_to_rownames("Sample")
# 免疫细胞浸润
data <- readxl::read_xlsx(paste0(Data_Center,'/Gene_Sets/immune_features/28celltype_gene_PMID28052254.xlsx'))
ssgsea_geneSets <- split(as.matrix(data)[, 1], data[, 2])
immunescore <- immune_score(
    exp = train_data$tumor_exprs, arrays = F, perm = 1000, group_list = NULL,
    tumor = T, scale_mrna = TRUE, od = od, ssgsea_geneSets = ssgsea_geneSets,
    method = c("ssgsea",'cibersort','estimate',"ips")
)
save(immunescore, file = str_glue("{od}/immunescore.RData"))
load(str_glue("{od}/immunescore.RData"))

# Adaptive
type28 <- readxl::read_xlsx(
    str_glue(("{Data_Center}/Gene_Sets/immune_features/28celltype_gene_PMID28052254.xlsx"))
    ,skip=2)
data <- type28 %>% 
    dplyr::filter(Immunity == "Adaptive") %>%
    pull(`Cell type`) %>%
    unique()
dir.create(str_glue("{od}/immune_infiltration"))
conflicts_prefer(clusterProfiler::rename)
conflicts_prefer(base::intersect)
conflicts_prefer(clusterProfiler::select)
a=immunescore$ssgsea %>% select(sample, data)
head(a)
conflicts_prefer(dplyr::between)
source("src/functions/v_characteristics_plot_by_group.R")
v_characteristics_plot_by_group(
    characteristics_score = immunescore$ssgsea %>% select(sample, data),,
    Group = NMF_Cluster,
    od = str_glue("{od}/ssgsea_adaptive"),
    type = "ssgsea",
    heatplot_by_scale = TRUE,
    cluster_rows = TRUE
)
# Innate
data <- type28 %>% 
    filter(Immunity == "Innate") %>%
    pull(`Cell type`) %>%
    unique()

v_characteristics_plot_by_group(
    characteristics_score = immunescore$ssgsea %>% select(sample, data),
    Group = NMF_Cluster,
    od = str_glue("{od}/ssgsea_innate/"),
    type = "ssgsea",
    heatplot_by_scale = TRUE, 
    cluster_rows = TRUE
)
str(immunescore$cibersort,2)
v_characteristics_plot_by_group(
    characteristics_score = immunescore$cibersort,
    Group = NMF_Cluster,
    od = str_glue("{od}/cibersort/"),
    type = "cibersort",
    heatplot_by_scale = TRUE, 
    cluster_rows = TRUE
)
v_characteristics_plot_by_group(
    characteristics_score = immunescore$estimate,
    Group = NMF_Cluster,
    od = str_glue("{od}/estimate/"),
    type = "cibersort",
    heatplot_by_scale = TRUE, 
    cluster_rows = TRUE
)

# other
geneSets <- GSEABase::getGmt("/Volumes/T7/DataHub/Gene_Sets/MsigDB/h.all.v2022.1.Hs.symbols.gmt")
hallmarkscore <- immune_score(
    exp = train_data$tumor_exprs, arrays = FALSE, perm = 200, group_list = NULL,
    tumor = TRUE, scale_mrna = TRUE, od = od, ssgsea_geneSets = geneSets,
    method = c("ssgsea")
)
save(hallmarkscore, file = str_glue("{od}/hallmarkscore.RData"))
load(str_glue("{od}/hallmarkscore.RData"))

v_characteristics_plot_by_group(
    characteristics_score = hallmarkscore$ssgsea,
    Group =  NMF_Cluster,
    od = str_glue("{od}hallmark"),
    type = "ssgsea",
    heatplot_by_scale = TRUE,
    cluster_rows = TRUE
)
