source("src/0.config.R")
od <- "结果/1.CRC中SUMO相关通路富集分析"
suppressWarnings(dir.create(od,recursive=TRUE))
using(clusterProfiler,data.table,enrichplot)

group_deg_res <- fread("结果/1.CRC中SUMO相关通路富集分析/SupplementaryTable_Tumor_vs_Normal_nrDEG.txt")

# 排序
geneList <- group_deg_res$logFC
names(geneList) <- group_deg_res$V1
geneList <- sort(geneList, decreasing = TRUE)

geneSets <- read.gmt(str_glue("{Data_Center}/Gene_Sets/MsigDB/msigdb.v2023.1.Hs.symbols.gmt"))

gsea_result <- GSEA(geneList,
        TERM2GENE = geneSets %>% dplyr::filter(grepl(pattern = "^REACTOME_SUMOYLATION", x = `term`, ignore.case = T)),
        eps = 0, pvalueCutoff = 1, pAdjustMethod = "BH"
    )
write.table(gsea_result, file = str_glue("{od}/SupplementaryTable_term.txt"), quote = FALSE, sep = "\t", col.names = TRUE, row.names = FALSE)

gseaplot2(gsea_result, 1:10, pvalue_table = T,base_size=15)
ggplot2::ggsave(str_glue("{od}/GSEA_Plot.pdf"),scale=2.5,width = 9,height = 6)
