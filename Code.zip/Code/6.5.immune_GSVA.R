# 导入函数
library(rjson)
library(data.table)
# 导入函数
source("src/0.config.R")
conflict_prefer("between", "dplyr",quiet = TRUE)
# 设置结果路径
od <- "结果/6.不同分子亚型的免疫治疗和化疗敏感性分析/GSVA"
suppressWarnings(dir.create(od,recursive=TRUE))

# 导入数据
load("data/train_data.RData")
load("data/xgene.RData")
NMF_Cluster <- fread("结果/3.构建SUMOylation相关的分子亚型/NMF_Cluster.csv",data.table = F)

# 导入数据
json <- fromJSON(file = "data/immune_gene/KEGG_ANTIGEN_PROCESSING_AND_PRESENTATION.v2022.1.Hs.json")
APAR <- json[[1]]$geneSymbols
json <- fromJSON(file = "data/immune_gene/KEGG_NOD_LIKE_RECEPTOR_SIGNALING_PATHWAY.v2022.1.Hs.json")
NLR <- json[[1]]$geneSymbols
json <- fromJSON(file = "data/immune_gene/KEGG_T_CELL_RECEPTOR_SIGNALING_PATHWAY.v2022.1.Hs.json")
TCR <- json[[1]]$geneSymbols
json <- fromJSON(file = "data/immune_gene/KEGG_TOLL_LIKE_RECEPTOR_SIGNALING_PATHWAY.v2022.1.Hs.json")
TLR <- json[[1]]$geneSymbols
json <- fromJSON(file = "data/immune_gene/REACTOME_C_TYPE_LECTIN_RECEPTORS_CLRS.v2022.1.Hs.json")
CLR <- json[[1]]$geneSymbols
immune_signature <- list(APAR=APAR,NLR=NLR,TCR=TCR,TLR=TLR,CLR=CLR)
save(immune_signature, file = "data/immune_signature.RData")

tumor_exprs <- train_data$tumor_exprs

ssgsea_res <- GSVA::gsva(
    expr = as.matrix(tumor_exprs),
    gset.idx.list = immune_signature,
    method = "gsva",
    ssgsea.norm = TRUE,
    verbose = T,
    parallel.sz = 16
)
str(ssgsea_res,2)
ssgsea_res %<>% t() %>% as_tibble(rownames = "Sample")
head(plot_data)
g <- merge(ssgsea_res,NMF_Cluster,by="Sample")
plot_data <- g[,-1] %>% pivot_longer(col=-Cluster)
#boxplot
library(ggpubr)
ggboxplot(plot_data,palette=color_fun1,
    x = "name", y = "value", fill = "Cluster",
    xlab = "", ylab = "",
    title = "", add = ""
) +
    stat_compare_means(aes(group=Cluster),label.y.npc = 1, label.x.npc = 0.4,size=5,label = "p.signif") +
    theme(plot.title=element_text(size=20,hjust=0.5),
        panel.grid = element_blank(), legend.title = element_blank(),
        # legend.position = "", 
        axis.title.x = element_text(size=14),
        axis.title.y = element_text( size=14),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        axis.text = element_text(color = "black")
    )
ggsave(filename = str_glue("{od}/Figure_GSVA_boxplot.pdf"),width=9,height = 6)
head(plot_data)
fwrite(plot_data,str_glue("{od}/GSVA.csv"))
