# 导入函数

source("src/0.config.R")
# 设置结果路径
od <- "结果/1.CRC中SUMO相关通路富集分析"
suppressWarnings(dir.create(od,recursive=TRUE))
# 导入数据
load("data/train_data.RData")
load('data/xgene.RData')

train_data$data_exprs %>% ncol() # 496
train_data$tumor_exprs %>% ncol() # 436
length(xgene) # 187

deg_res <- limma_deg(
    od = od,
    DEG_exp = train_data$data_exprs, 
    DEG_pdata = train_data$data_pdata,
    controlLabel = "Normal",
    caseLabel = 'Tumor',
    DEG_FC = parameter_list$log2fc, 
    DEG_P = parameter_list$deg_p, 
    pvalue = NULL, 
    saveplot = T, 
    color_fun = color_fun1
)
# Tumor_vs_Normal
# log2FC=1,FDR=0.01
# DEGs up down
# 3444 1885 1559
